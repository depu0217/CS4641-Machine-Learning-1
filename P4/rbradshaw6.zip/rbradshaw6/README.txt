To run:
cd RL_sim
java -jar rl_sim.jar

Choose the algorithm you want to run and load the maze files in the GUI. Click initialize, then set the parameters and click the Execute button (or the Cycles button for Policy Sweeping).