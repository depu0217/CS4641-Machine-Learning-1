README

All of these were run using WEKA GUI on Windows. I saved some of the result buffers in the �sup� folder in this directory. 

Change K in IBK for KNN.
Change C along with Kernel in SMO. 
Change confidence factors in J48 decision tree and Adaboosted J48. 
Change hiddenLayers variable in MultilayerPerceptron.

